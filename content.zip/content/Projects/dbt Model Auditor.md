---
tags:
    - dbt 
    - sql
---

📎 [Blog Post](https://dev.to/ahmadmuhammad/dbt-data-quality-audit-but-on-steroid-4bi9) | [GitHub Repo](https://github.com/ahmadMuhammadGd/dbt-audit-on-steroid)


**Why**:  
dbt test's results will always replace previous failures for the same test.

**What**:  
Store failures `historically` for data quality traceability.

**How**:  
- Used `dbt graph context` to traverse and process model dependencies.

- Generalized dbt macro to store these errors.

- Simple bash-orchestrated `Write-Audit-Publish (WAP)` pipeline with this approach.

