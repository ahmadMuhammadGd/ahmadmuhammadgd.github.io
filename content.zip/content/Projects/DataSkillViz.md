---
tags:
  - data-mining
  - python
  - airflow
  - sql
  - streamlit
  - NLP
---

📎 [Go Live](https://dataskillviz.streamlit.app/)


**Why:**  
- Recruiters and engineers think differently. 
- Engineers value fundamentals, problem-solving, and tool-agnostic approaches.
- recruiters filter for current tool-sets and measurable impact. 
- This gap amplified by automated resume screening, hurts juniors the most.



**What:**  
- Analyzed 40k+ job postings and 400+ data-related tools to map tool demand and co-occurrence patterns. 
- Shows where your skill-set stands in the market.
- Built for engineers who want to navigate recruiter filters without chasing hype.


**How:**  
- `Postgres` + `Kimball modeling` + `fastText embeddings` + `Airflow` ETL pipeline feeding a `Streamlit` app. 
![home page](DataSkillViz-home.gif)  
- Jobs are parsed, tools are extracted and semantically linked, and visualizations (tool demand charts, association graphs) are rendered for market insight.  
![frequency pattern](DataSkillViz-fp.gif)  


> Companies move slowly with their stack; one data refresh a year is enough.

> ==I’m on the free tier for both Streamlit and Aiven. If something goes wrong, it’s likely because they shut down my instances due to inactivity, contact me if that happens.==