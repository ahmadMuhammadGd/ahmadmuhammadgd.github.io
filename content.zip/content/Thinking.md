- Prefer pipelines as **code**, not GUIs.

- Every transformation should be:
  - Transparent  
  - Versioned  
  - Idempotent  
  - Testable  
  - Reproducible

- Pipelines encode business meaning layer by layer: raw → staged → modeled.

- Dashboards don't define truth. **Contracts do**.

- ~~What works in SQL should be in SQL~~ ==I was wrong. Complex transformations are often cleaner in Python.==

- Governance is not luxury, it's a must.

--- 

- Your pipeline is not done if it’s undocumented.
- Your model is not tested if it breaks silently.