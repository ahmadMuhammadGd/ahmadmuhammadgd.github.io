---
tags:
  - s3
  - spark
  - python
  - airflow
  - sql
  - dbt
---


# Ahmad Muhammad  
**Data Engineer** | Egypt 🇪🇬



## TL;DR

- 🔧 Built a custom cli ingestion framework to normalize 300+ inconsistent flat files at scale @ NTRA Egypt.

- 🤜 Processed **40K+** data job postings, mined hidden skill co-occurrence patterns, performed NLP, and published the results in an interactive [DataSkillViz](./Projects/DataSkillViz.md) Streamlit app.

- ✍️ No-fluff technical writing, see [my blogs](Blogs)  

- 💥 Full-featured Data Lakehouses in addition to Analytics Engineering, see [my work](Projects)

---
## Social Links
[LinkedIn](https://www.linkedin.com/in/ahmadmuhammadgd/) • [GitHub](https://github.com/ahmadMuhammadGd/) • [DEV](https://dev.to/ahmadmuhammad/)

<!-- ## Vault Map

- [[Philosophy]] → Opinions on data modeling, ELT, and tooling
- [[Articles]] → Published pieces from DEV with internal notes
- [[Projects]] → Case studies of ingestion frameworks, dbt pipelines, etc.
- [[Anti-Patterns]] → Practices I avoid and why
- [[Stack]] → Tools I use, how, and when not to -->

<!-- ## 👋 Hey There 
> I am Ahmad Muhammad, a data engineer based in Egypt 
[Linkedin](https://www.linkedin.com/in/ahmadmuhammadgd/) | [GitHub](example.com) | [DEV](example.com)

----

## 🤕 Philosophy

- Prefer pipelines as **code**, not GUIs.

- Every transformation should be:
  - Transparent  
  - Versioned  
  - Idempotent  
  - Testable  
  - Reproducible

- Pipelines encode business meaning layer by layer — raw → staged → modeled.

- Dashboards don't define truth. **Contracts do**.


## ✍️ Articles
- [🪨 The Myth of Sisyphus in Data Engineering](https://dev.to/ahmadmuhammad/the-myth-of-sisyphus-in-data-engineering-4j9e)
- [🔍 dbt Data Quality Audit, But on Steroid](https://dev.to/ahmadmuhammad/dbt-data-quality-audit-but-on-steroid-4bi9)
- [🔧 What the heck is data build tool (dbt)](https://dev.to/ahmadmuhammad/what-the-heck-is-data-build-tool-dbt-179d)

---

## 🛠 Experience
### Data Engineer @ National Telecom Regulatory Authority, Egypt | Feb 2025 - Now

- Built a configurable ingestion framework for flat files (CSV, Excel, JSON, Parquet).  
  → Enabled automated EL processing of 200+ inconsistent files.

- Designed dbt models for analytics pipelines.  
  → Used testing, CI/CD, governance, and source-layer tracking.

- Supported downstream dashboards without hardcoding any logic into BI tools.

**Stack**: Python, SQL, dbt, Postgres, SQL Server, SSIS, Docker  
**Data formats**: Parquet, CSV, JSON, Excel

----

> **Technology Stack:**
> `Docker` , `Airflow`, `Python`, `Spark`, `MongoDB`, `MySQL`, `IceBerg`, and `Bash` -->
