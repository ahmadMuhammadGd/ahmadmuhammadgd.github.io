---
tags:
    - dbt 
    - sql
---


📎 [Blog Post](https://dev.to/ahmadmuhammad/what-the-heck-is-data-build-tool-dbt-179d)



**Why:**  
People struggle to understand the idea behind it.

**What:**  
Walkthrough blog to explain dbt features quickly.

